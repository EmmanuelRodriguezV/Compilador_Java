// This is a comment /* */ */

/*  aisuhaisudh /
 Aisuhdi // Asd
 // Test *
*/

// Empty Stmt
;
// NamespaceDefinition

double ndfs1( int p1, bool p2, char p3, float p4 )
{
	int a1;
	int b2 = 10000001231;
	
	int c = -20;
	int d = "2";	// THIS IS NOT AN INT
	
	int e, f, g, h;


	bool b = TRUE;
	bool f = FALSE;
	bool b1, b2 = TRUE;

	bool c2 = ~(b && c) || (TRUE ^ FALSE )|| ~(2 < 5);

	for ( int a; a < 10; a++) {
		

		for ( int a; a < a; a++) {
			break;
		}

		while ( a == "THIS IS A STRING.!**!&!)_!&^$@!!$! (!*(!* !*!*& // \n\n" ) {
			if ( a == a ) {
				return b;

			} else {
				if (a == 10) {
					continue;
				}
			}
		}

		do {

		} while (a == "Say \"hello\" to the nice people!\n");

	}

	return a;
}

int metod() {

	/* x = ndfs1(b); */

	switch (x) {
	}

	if (b==b) {
		goto stop;
	}


	return b;
}

void relationalOperators() {

   int a = 21;
   int b = 10;
   int c ;

   if( a == b && a != 50 )
   {
      
   }
   else if( a < b )
   {
    
   }
   else if ( a > b )
   {
      
   }
   else if ( a <= b )
   {

   }

   if ( b >= a )
   {

   }

}

void arithmeticOperators() 
{
	double a = 2 + 2;
	int b = 2 - a;
	int c = a * b;

	int d = b/d;

	int a = mod % 10;

	int expression = (a+ (-b))  + ((i++) * 2 ) / (a*b);
	int i = --i;

}
