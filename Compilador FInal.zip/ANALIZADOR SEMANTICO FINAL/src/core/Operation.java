
package core;

/**
 *	A C Operation... Nodes are the parameters of the operation...
 */
public enum Operation {
	PLUS, MINUS, MULT, DIV, PERC, LE_OP, GE_OP, LESS_THAN, MORE_THAN, EQ_OP, NE_OP, AND_OP, OR_OP;
}
