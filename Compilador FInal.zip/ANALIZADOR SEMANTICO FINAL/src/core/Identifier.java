package core;

public interface Identifier {
	
	public String toString();
}
