package core;

public interface Parameter {
	
	public Type getType();

}
